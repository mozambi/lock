package com.example.eight;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	TextView textView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		textView = (TextView) findViewById(R.id.textView1);
	}

	// Inflate the menu
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main_menu, menu);
		return true;
	}

	// Handle menu item clicks
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.menu_about:
			textView.setText("You selected About");
			Toast.makeText(this, "About clicked", Toast.LENGTH_SHORT).show();
			return true;

		case R.id.menu_settings:
			textView.setText("You selected Settings");
			Toast.makeText(this, "Settings clicked", Toast.LENGTH_SHORT).show();
			return true;

		case R.id.menu_exit:
			Toast.makeText(this, "Exiting...", Toast.LENGTH_SHORT).show();
			finish(); // Close the activity
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}
}